//
//  ViewController.swift
//  Xylophone
//

//

import UIKit
//import AudioToolbox
import AVFoundation

class ViewController: UIViewController,AVAudioPlayerDelegate{
    
    var audioPlayer: AVAudioPlayer!
    
    
    let soundArray = ["note1","note2","note3","note4","note5","note6","note7"]

    override func viewDidLoad() {
        super.viewDidLoad()
    }



    @IBAction func notePressed(_ sender: UIButton) {
        
        /*if let soundURL = Bundle.main.url(forResource: "note1", withExtension: "wav"){
        var mySound: SystemSoundID = 0
        AudioServicesCreateSystemSoundID(soundURL as CFURL, &mySound)
        //Play
        
        AudioServicesPlaySystemSound(mySound);
           }*/
        
        
        
        playSound(selectedSoundFileName: soundArray[sender.tag - 1] )
        
        
        }
    func playSound(selectedSoundFileName: String){
        
        let soundURL = Bundle.main.url(forResource: selectedSoundFileName, withExtension: "wav")
        do{
            audioPlayer = try AVAudioPlayer(contentsOf: soundURL!)
        }
        catch{
            print(error)
        }
        audioPlayer.play()

        
    }
}
