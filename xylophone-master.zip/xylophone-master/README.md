# Xylophone
Learn to make iOS Apps with the [London App Brewery](http://online.londonappbrewery.com)

Project Stub | (Swift 3.0/Xcode 8) - Xylophone App

Download the starter project files as .zip and extract to your desktop. 

## Finished App
<img src="https://github.com/londonappbrewery/Images/blob/master/Xylophone.png" width="400">

Copyright © London App Brewery
